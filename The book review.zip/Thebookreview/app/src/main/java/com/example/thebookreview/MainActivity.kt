package com.example.thebookreview

import android.R.attr.author
import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat.startActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.thebookreview.BookRepository.Companion.Book


private var Nothing?.hint: String

class MainActivity: AppCompatActivity()

fun onCreat(savedinstanceState:Bundle?){
     super.onCreate(savedinstanceState)
    setContentView(R.layout.activity_main)


    val btnEnterbook = findViewById<Button>(R.id.btnEnterbook)

    btnEnterbook.setOnClickLstener {
        showBookInputDialog()


    }



}

private fun Unit.setOnClickLstener(function: () -> Unit) {


}

fun findViewById(btnEnterbook: Int) {


}

fun setContentView(activityMain: Int) {


}

private fun showBookInputDialog(){

    val layout = LinearLayout(/* context = */ this)
    layout.orientation = LinearLayout.VERTICAL
    layout.setPadding(50,40,50,10)


    val titleInput = EditText(/* context = */ this)
    val titleinput = null
    titleinput.hint= "Enter Book Title"


    val authorInput = EditText(this)
    authorInput.hint= "ENTER AUTHOR NAME"


    layout.addView(titleInput)
    layout.addView(authorInput)

    val alertDialog = null
    alertDialog.Builder(this)
        .setTitle("Book Details")
        .setView(layout)
        .setPositiveButton("Save"){
            val title = titleInput.text.toString()


            BookRepository.book =Book(title,author =author)
            startActivity(intent(
                value = this, java = detailedscreen::class.java
            ))

        }













}

private fun Unit.setPositiveButton(string: String, function: () -> Unit) {
    TODO("Not yet implemented")
}

private fun Unit.setView(layout: LinearLayout) {
    TODO("Not yet implemented")
}

private fun Unit.setTitle(string: String) {


}

private fun Nothing?.Builder(value: Any) {
    TODO("Not yet implemented")
}

fun startActivity(context: Context) {


}

fun intent(
    value: Any,
    java: Class<detailedscreen>
): Context {
    TODO("Not yet implemented")
}





























