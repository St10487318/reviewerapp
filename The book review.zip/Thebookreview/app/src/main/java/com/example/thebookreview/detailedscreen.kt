package com.example.thebookreview

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.benchmark.traceprocessor.Row
import com.example.thebookreview.BookRepository.Companion.Companion


private val Any.layout: Any
    get() {
        TODO()
    }
private val Any.foundation: Any
    get() {
        TODO()
    }
private val Any.compose: Any
    get() {
        TODO()
    }
private val IntRange.androidx: Any
    get() {
        TODO()
    }
private val Any.comments: Any
    get() {
        TODO()
    }
private val Any.size: String
    get() {
        TODO()
    }
private val Any.author: String
    get() {
        TODO()
    }
private val Any.title: String
    get() {
        TODO()
    }
private val Any.average: Any
    get() {
        TODO()
    }
private val Any.commentS: Any
    get() {
        TODO()
    }
private val Any.ratings: Any
    get() {
        TODO()
    }
private var Companion.book: Any
    get() {
        TODO()
    }

class detailedscreen : AppCompatActivity(){


    @SuppressLint("WrongViewCast", "MissingInflatedId")
    override fun onCreate(savedInstanceState:Bundle?){

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detailedscreen)


        val txtBookinfo = findViewById<TextView>(R.id.txtBookinfo)
        val edtRating = findViewById<EditText>(R.id.edtRating)
        val edtcomment = findViewById<EditText>(R.id.edtcomment)
        val btnAddReview = findViewById<Button>(R.id.btnAddReview)
        val btnaverage = findViewById<Button>(R.id.btnaverage)
        val btnDisplaybook = findViewById<Button>(R.id.btnDisplaybook)
        var txtOutput = findViewById<TextView>(R.id.txtOutput)
          val Book = BookRepository.Book


        txtBookinfo.text ="Add rating and comment"

        btnAddReview.setOnClickListener {
            if (Book ==null){
                Toast.makeText(this,"No Book saved", Toast.LENGTH_SHORT).show()
                return@setOnClickListener



            }

            val ratingText = edtRating.text.toString()
            val commentText: String = edtcomment.text.toString()

            if (ratingText.isEmpty()|| commentText.isEmpty()){
                Toast.makeText(this,"Enter rating and comment",Toast.LENGTH_SHORT).show()
                return@setOnClickListener

            }

            val rating: String = ratingText.toInt().toString()
            if (!(1..5).androidx.compose.foundation.layout.Row {
                    val contains = contains(rating)
                    contains
                }){
                Toast.makeText(this, "Rating must be between 1 and 5",Toast.LENGTH_SHORT)
                return@setOnClickListener

            }

            Book.ratings.add(rating)
            Book.commentS.add(commentText)


            edtcomment.text.clear()
            edtRating.text.clear()
            Toast.makeText(this, "Review added", Toast.LENGTH_SHORT).show()

        }
        btnaverage.setOnClickListener {
            if (Book == null){
                txtOutput.text = "no book found"
                return@setOnClickListener
            }

            if (Book.ratings.isEmpty()){
                txtOutput.text ="No ratings added"
                return@setOnClickListener

            }
            val avg = Book.ratings.average
            txtOutput.text = "Average Rating:%.2f".format(avg)

        }
        btnDisplaybook.setOnClickListener {
            if(Book == null){
                txtOutput.text ="No book entered"
                return@setOnClickListener

            }
            val details = """"
                Book Title:${Book.title}
                Author:${Book.author}
                Ratings Count:${Book.ratings.size}
                Comments Count:${Book.comments.size}
                """.trimIndent()
            details.also { it.also { val also = it.also { it -> txtOutput = it } } }
        }

    }
}

private fun Any.Row(function: Any): Boolean {
    TODO("Not yet implemented")
}

private fun Any.isEmpty(): Boolean {
    TODO("Not yet implemented")
}

private fun Any.add(rating: String) {


}

class BookRepository {

    companion object {
        val Book: Any
            get() {
                TODO()
            }

        class Companion {

        }
    }

}


















